void enter_pedo_mode(void);
void enter_temp_mode(void);
void enter_cmps_mode(void);
